import express from "express";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import midtransClient from "midtrans-client";
import nodemailer from "nodemailer";

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const snap = new midtransClient.Snap({
  isProduction: process.env.MIDTRANS_IS_PRODUCTION === "true",
  serverKey: process.env.MIDTRANS_SERVER_KEY,
  clientKey: process.env.MIDTRANS_CLIENT_KEY
});

const products = [
  { id:"tee-01", name:"ROT Signature Tee", price:249000, category:"T-Shirt", image:"/assets/product-1.svg", description:"Heavyweight cotton tee dengan siluet clean dan relaxed." },
  { id:"tee-02", name:"Essential Box Tee", price:279000, category:"T-Shirt", image:"/assets/product-2.svg", description:"Boxy fit premium untuk tampilan minimal." },
  { id:"pant-01", name:"Utility Wide Pants", price:499000, category:"Pants", image:"/assets/product-3.svg", description:"Wide silhouette dengan detail utilitarian." },
  { id:"hood-01", name:"Core Zip Hoodie", price:599000, category:"Outerwear", image:"/assets/product-4.svg", description:"Hoodie heavyweight dengan konstruksi premium." }
];

app.get("/api/products", (_, res) => res.json(products));

app.post("/api/create-transaction", async (req, res) => {
  try {
    const { orderId, customer, items } = req.body;
    if (!orderId || !customer?.email || !Array.isArray(items) || !items.length) {
      return res.status(400).json({ error: "Data pesanan belum lengkap." });
    }

    const lineItems = items.map(i => {
      const p = products.find(x => x.id === i.id);
      if (!p) throw new Error("Produk tidak ditemukan.");
      const qty = Math.max(1, Number(i.qty || 1));
      return { id:p.id, price:p.price, quantity:qty, name:p.name };
    });

    const grossAmount = lineItems.reduce((sum, x) => sum + x.price * x.quantity, 0);

    const parameter = {
      transaction_details: { order_id: orderId, gross_amount: grossAmount },
      item_details: lineItems,
      customer_details: {
        first_name: customer.name,
        email: customer.email,
        phone: customer.phone || ""
      },
      callbacks: { finish: `${req.protocol}://${req.get("host")}/success.html` }
    };

    const transaction = await snap.createTransaction(parameter);
    res.json({ token: transaction.token, redirect_url: transaction.redirect_url, orderId, grossAmount });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || "Gagal membuat pembayaran." });
  }
});

app.post("/api/notify", async (req, res) => {
  try {
    const notification = req.body;
    console.log("Midtrans notification:", notification);

    const status = notification.transaction_status;
    const orderId = notification.order_id;
    const fraud = notification.fraud_status;

    if (["settlement", "capture"].includes(status) && (!fraud || fraud === "accept")) {
      await sendOrderEmail(notification);
    }

    res.status(200).json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Notification handling failed." });
  }
});

async function sendOrderEmail(n) {
  if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD || !process.env.BRAND_NOTIFICATION_EMAIL) {
    console.warn("Gmail belum dikonfigurasi. Pesanan:", n.order_id);
    return;
  }
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_APP_PASSWORD }
  });

  await transporter.sendMail({
    from: `"${process.env.STORE_NAME || "Store"}" <${process.env.GMAIL_USER}>`,
    to: process.env.BRAND_NOTIFICATION_EMAIL,
    subject: `Pesanan baru dibayar — ${n.order_id}`,
    html: `
      <div style="font-family:Arial,sans-serif;line-height:1.6">
        <h2>Pesanan baru berhasil dibayar</h2>
        <p><b>Order ID:</b> ${n.order_id}</p>
        <p><b>Status:</b> ${n.transaction_status}</p>
        <p><b>Total:</b> Rp ${Number(n.gross_amount || 0).toLocaleString("id-ID")}</p>
        <p><b>Metode:</b> ${n.payment_type || "-"}</p>
        <p>Silakan cek dashboard Midtrans untuk detail transaksi dan alamat pelanggan.</p>
      </div>`
  });
}

app.get("*splat", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`ROT store running at http://localhost:${port}`));